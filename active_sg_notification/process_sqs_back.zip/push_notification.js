
/* body
{
	notification_queue_id: ""
	notification_type: ""
	recipient_id: ""
	recipient_type: ""
	notification_send_at: ""
	notification_text: ""
	option: ""
	is_send: ""
	send_success: ""
	resend_count: ""
	account_id: ""
	send_from: ""
	notification_subject: ""
	sender_name: ""
	sender_id: ""
	badge: ""
	is_cancel: ""
	created_at: ""
	created_by: ""
	updated_at: ""
	updated_by: ""
	deleted_at: ""
	deleted_by: ""
}
*/
module.exports = (body) => {

	return {
		"notify": () => {
			console.log('push_notification.js under construction');
			return false;
		}
	}
}