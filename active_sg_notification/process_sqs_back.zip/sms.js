const messagebird = require('messagebird')(process.env.messageBirdAccessKey);

/* body
{
	notification_queue_id: ""
	notification_type: ""
	recipient_id: ""
	recipient_type: ""
	notification_send_at: ""
	notification_text: ""
	option: ""
	is_send: ""
	send_success: ""
	resend_count: ""
	account_id: ""
	send_from: ""
	notification_subject: ""
	sender_name: ""
	sender_id: ""
	badge: ""
	is_cancel: ""
	created_at: ""
	created_by: ""
	updated_at: ""
	updated_by: ""
	deleted_at: ""
	deleted_by: ""
}
*/
module.exports = function (body) {

	this.queueId = body.notification_queue_id;
	this.sender = body.sender_name;
	this.recipient = body.recipient_id;
	this.message = body.notification_text;

	return {
		"notify": (callback) => {
			console.log(`sending sms notification. notification queue id: ${this.queueId}`);
			let params = {
				originator: this.sender,
			  	recipients: [this.recipient],
			  	body: this.message
			};

			messagebird.messages.create(params, (error, response) => {
				if (error) {
			  		console.log(`sms.js error notification queue id 
			  			${this.queueId} ${JSON.stringify(error)}`
			  		);
			  		return;
			  	}
			  	console.log(`sms notification sent. notification queue id: ${this.queueId}`);
			  	return callback;
			});
		}
	}
}